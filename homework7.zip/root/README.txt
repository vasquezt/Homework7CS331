Name: Trent Vasquez
Shell Script: homework.sh
Ansible Playbook: webserver.yaml

Expected Output: Should output the curl of the 4 webservers to the tempfile file

Notes: Please be patient with the script, there is a part where it takes a minute or two to work 

