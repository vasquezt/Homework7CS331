#!/bin/bash
echo "Start of Bash Script"
yum install -y nmap 
yum install -y ifconfig

ifconfig | grep -oP '\d+\.\d+\.\d+.\d+' > hostip
nmap -sP 192.168.1.* | grep -oP '\d+\.\d+\.\d+\.\d+' > nmap_output 

hostIp=$(sed -n '1p' < hostip)

tail -n +2 nmap_output > connections
while read p; do
  if [[ "$hostIp" != "$p" ]]; then
    echo "$p" >> clients
  fi
done < connections
rm nmap_output
rm hostip

yes "" | ssh-keygen -t rsa

yum install sshpass
echo "StrictHostKeyChecking no" > /etc/ssh/ssh_config
while read p; do 
  sshpass -p password ssh-copy-id -i /root/.ssh/id_rsa.pub root@"$p"
done < clients

echo "[mynodes]" > hosts.ini
while read p; do
  echo "$p" >> hosts.ini
done < clients

echo "" >> hosts.ini
echo "[mynodes:vars]" >> hosts.ini
echo "ansible_connection=ssh" >> hosts.ini
echo "ansible_port=22" >> hosts.ini
echo "ansible_user=root" >> hosts.ini
# echo "ansible_python_interpreter=/usr/bin/python3" >> hosts.ini

ansible mynodes -i ./hosts.ini -b -m raw -a "apk -U add python3"

now=$(date)
ansible-playbook webserver.yaml -i ./hosts.ini --extra-vars "date=${now}" 

while read p; do
  echo "Curl for "$p""
  curl "$p" >> tempfile
done < clients

echo "Curled webpages have been appended to tempfile"

rm hosts.ini
rm connections
rm clients
